#include "Calculator.h"
#include "loop.h"
#include <tchar.h>

int _tmain(int argc, _TCHAR* argv[])
{
	main::loop::therealloop::realMain();
	return 0;
}